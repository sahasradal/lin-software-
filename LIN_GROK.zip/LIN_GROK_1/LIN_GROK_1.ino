#include <SoftwareSerial.h>
// tested works fine but displays only valid checksum messages
const int linRX = 2; 
//SoftwareSerial linBus(linRX, -1); // RX only for sniffing
SoftwareSerial linBus(2, 3);
long detectedBaud = 0;
uint8_t frameBuffer[12];
int bufIdx = 0;

void setup() {
  Serial.begin(115200);
 // pinMode(linRX, INPUT);
  Serial.println("--- LIN 2.x Auto-Baud Sniffer Starting ---");
}

void loop() {
       
  // 1. If baud is not yet detected, find it from the bus traffic
  if (detectedBaud == 0) {
    detectedBaud = autoDetectBaud(linRX);
    if (detectedBaud > 0) {
      Serial.print("Detected Baud: "); Serial.println(detectedBaud);
      linBus.begin(detectedBaud);
      //linBus.begin(10417);
    }
    return;
  }

  // 2. Read incoming traffic
  if (linBus.available()) {
    uint8_t b = linBus.read();
    
    // LIN Sync Field is always 0x55
    if (b == 0x55) {
      processLastFrame(); // Process the previous frame before starting new one
      bufIdx = 0;
    }
    
    if (bufIdx < 12) frameBuffer[bufIdx++] = b;
  }
}

// Measures the bit-width of the 0x55 Sync byte to find the baud rate
long autoDetectBaud(int pin) {
  // Wait for the 'Break' (Low signal > 13 bits)
  while(pulseIn(pin, LOW, 500000) < 500); 

  // Measure the first LOW bit of the 0x55 Sync byte
  long bitWidth = pulseIn(pin, LOW, 10000); 
  if (bitWidth <= 0) return 0;

  long raw = 1000000 / bitWidth;
  
  // Snap to standard automotive speeds
  if (raw > 18000 && raw < 21000) return 19200;
  if (raw > 9500 && raw < 11500)  return 10417; // Common GM Speed
  return raw;
}

void processLastFrame() {

  if (bufIdx < 4) return;                    // Need Sync + PID + at least 1 data + checksum

 

  uint8_t fullPID          = frameBuffer[1];   // Protected ID actually transmitted (e.g. 0xC1 for raw ID 0x01)

  uint8_t rawID            = fullPID & 0x3F;   // Raw frame ID you want to display (0x01, 0x04, ...)

  uint8_t receivedChecksum = frameBuffer[bufIdx - 1];

 

  uint8_t dataStart = 2;                     // First data byte index

  uint8_t dataEnd   = bufIdx - 2;            // Last data byte (before checksum)

 

  // Decide checksum type automatically

  bool useEnhanced = true;

  if (rawID == 0x3C || rawID == 0x3D) {

    useEnhanced = false;                     // Diagnostic frames MUST use Classic checksum

  }

 

  // Calculate checksum

  uint16_t sum = useEnhanced ? fullPID : 0;   // Start with full PID for Enhanced, 0 for Classic

 

  for (uint8_t i = dataStart; i < bufIdx - 1; i++) {

    sum += frameBuffer[i];

    if (sum >= 256) sum -= 255;

  }

 

  uint8_t calculated = (~sum) & 0xFF;

 

  // === Print output ===

  Serial.print("ID: 0x");

  if (rawID < 0x10) Serial.print("0");

  Serial.print(rawID, HEX);

 

  Serial.print(" Data: ");

  for (uint8_t i = dataStart; i < bufIdx - 1; i++) {

    if (frameBuffer[i] < 0x10) Serial.print("0");

    Serial.print(frameBuffer[i], HEX);

    Serial.print(" ");

  }

 

  // Show checksum type for debugging

  Serial.print(useEnhanced ? "[Enhanced] " : "[Classic] ");

 

  if (calculated == receivedChecksum) {

    Serial.println("[OK]");

  } else {

    Serial.print("[CHECKSUM ERROR: Calc 0x");

    if (calculated < 0x10) Serial.print("0");

    Serial.print(calculated, HEX);

    Serial.print("  Recv 0x");

    if (receivedChecksum < 0x10) Serial.print("0");

    Serial.print(receivedChecksum, HEX);

    Serial.println("]");

  }

}

 

 
  
