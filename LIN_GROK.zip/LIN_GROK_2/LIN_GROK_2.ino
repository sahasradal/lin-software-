#include <SoftwareSerial.h>

const int linRX = 2; 
//SoftwareSerial linBus(linRX, -1); // RX only for sniffing
SoftwareSerial linBus(2, 3);
long detectedBaud = 0;
uint8_t frameBuffer[12];
int bufIdx = 0;

void setup() {
  Serial.begin(115200);
 // pinMode(linRX, INPUT);
  Serial.println("--- LIN 2.x Auto-Baud Sniffer Starting ---");
}

void loop() {
       
  // 1. If baud is not yet detected, find it from the bus traffic
  if (detectedBaud == 0) {
    detectedBaud = autoDetectBaud(linRX);
    if (detectedBaud > 0) {
      Serial.print("Detected Baud: "); Serial.println(detectedBaud);
      linBus.begin(detectedBaud);
      //linBus.begin(10417);
    }
    return;
  }

  // 2. Read incoming traffic
  if (linBus.available()) {
    uint8_t b = linBus.read();
    
    // LIN Sync Field is always 0x55
    if (b == 0x55) {
      processLastFrame(); // Process the previous frame before starting new one
      bufIdx = 0;
    }
    
    if (bufIdx < 12) frameBuffer[bufIdx++] = b;
  }
}

// Measures the bit-width of the 0x55 Sync byte to find the baud rate
long autoDetectBaud(int pin) {
  // Wait for the 'Break' (Low signal > 13 bits)
  while(pulseIn(pin, LOW, 500000) < 500); 

  // Measure the first LOW bit of the 0x55 Sync byte
  long bitWidth = pulseIn(pin, LOW, 10000); 
  if (bitWidth <= 0) return 0;

  long raw = 1000000 / bitWidth;
  
  // Snap to standard automotive speeds
  if (raw > 18000 && raw < 21000) return 19200;
  if (raw > 9500 && raw < 11500)  return 10417; // Common GM Speed
  return raw;
}

void processLastFrame() {

  if (bufIdx < 4) return;

 

  uint8_t fullPID          = frameBuffer[1];

  uint8_t rawID            = fullPID & 0x3F;

  uint8_t receivedChecksum = frameBuffer[bufIdx - 1];

 

  uint8_t dataStart = 2;

  uint8_t maxData   = bufIdx - 3;        // maximum possible data bytes

 

  // Possible lengths to try (most common first for your bus)

  const uint8_t possibleLengths[] = {8, 6, 4, 2};

  uint8_t detectedLen = 0;

  uint8_t calculated  = 0;

 

  for (uint8_t i = 0; i < 4; i++) {

    uint8_t len = possibleLengths[i];

    if (len > maxData) continue;

 

    // Calculate Enhanced checksum

    uint16_t sum = fullPID;

    for (uint8_t j = 0; j < len; j++) {

      sum += frameBuffer[dataStart + j];

      if (sum >= 256) sum -= 255;

    }

    calculated = (~sum) & 0xFF;

 

    if (calculated == receivedChecksum) {

      detectedLen = len;

      break;

    }

  }

 

  // If nothing matched, fall back to max possible with error

  if (detectedLen == 0) {

    detectedLen = maxData;

    // Recalculate for error reporting

    uint16_t sum = fullPID;

    for (uint8_t j = 0; j < detectedLen; j++) {

      sum += frameBuffer[dataStart + j];

      if (sum >= 256) sum -= 255;

    }

    calculated = (~sum) & 0xFF;

  }

 

  // === Print ===

  Serial.print("ID: 0x");

  if (rawID < 0x10) Serial.print("0");

  Serial.print(rawID, HEX);

 

  Serial.print(" Data: ");

  for (uint8_t i = 0; i < detectedLen; i++) {

    if (frameBuffer[dataStart + i] < 0x10) Serial.print("0");

    Serial.print(frameBuffer[dataStart + i], HEX);

    Serial.print(" ");

  }

 

  Serial.print("[Enhanced] ");

 

  if (calculated == receivedChecksum) {

    Serial.println("[OK]");

  } else {

    Serial.print("[CHECKSUM ERROR: Calc 0x");

    if (calculated < 0x10) Serial.print("0");

    Serial.print(calculated, HEX);

    Serial.print("  Recv 0x");

    if (receivedChecksum < 0x10) Serial.print("0");

    Serial.print(receivedChecksum, HEX);

    Serial.println("]");

  }

}
 

 
  
