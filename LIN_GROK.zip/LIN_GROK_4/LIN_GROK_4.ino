#include <SoftwareSerial.h>

const int linRX = 2; 
//SoftwareSerial linBus(linRX, -1); // RX only for sniffing
SoftwareSerial linBus(2, 3);
long detectedBaud = 0;
uint8_t frameBuffer[12];
int bufIdx = 0;

void setup() {
  Serial.begin(115200);
 // pinMode(linRX, INPUT);
  Serial.println("--- LIN 2.x Auto-Baud Sniffer Starting ---");
}

void loop() {
       
  // 1. If baud is not yet detected, find it from the bus traffic
  if (detectedBaud == 0) {
    detectedBaud = autoDetectBaud(linRX);
    if (detectedBaud > 0) {
      Serial.print("Detected Baud: "); Serial.println(detectedBaud);
      linBus.begin(detectedBaud);
      //linBus.begin(10417);
    }
    return;
  }

  // 2. Read incoming traffic
  if (linBus.available()) {
    uint8_t b = linBus.read();
    
    // LIN Sync Field is always 0x55
    if (b == 0x55) {
      processLastFrame(); // Process the previous frame before starting new one
      bufIdx = 0;
    }
    
    if (bufIdx < 12) frameBuffer[bufIdx++] = b;
  }
}

// Measures the bit-width of the 0x55 Sync byte to find the baud rate
long autoDetectBaud(int pin) {
  // Wait for the 'Break' (Low signal > 13 bits)
  while(pulseIn(pin, LOW, 500000) < 500); 

  // Measure the first LOW bit of the 0x55 Sync byte
  long bitWidth = pulseIn(pin, LOW, 10000); 
  if (bitWidth <= 0) return 0;

  long raw = 1000000 / bitWidth;
  
  // Snap to standard automotive speeds
  if (raw > 18000 && raw < 21000) return 19200;
  if (raw > 9500 && raw < 11500)  return 10417; // Common GM Speed
  return raw;
}

void processLastFrame() {

  if (bufIdx < 4) return;

 

  uint8_t fullPID          = frameBuffer[1];     // Protected ID (what is actually sent on bus)

  uint8_t rawID            = fullPID & 0x3F;     // Raw ID (0x01, 0x16, etc.)

  uint8_t receivedChecksum = frameBuffer[bufIdx - 1];

 

  uint8_t dataStart     = 2;

  uint8_t maxDataLen    = bufIdx - 3;

 

  // Try common lengths - 6 is most frequent on your Tahoe IBS

  const uint8_t possibleLengths[] = {6, 8, 4, 2};

  uint8_t detectedLen = 0;

  uint8_t calculated  = 0;

 

  for (uint8_t i = 0; i < 4; i++) {

    uint8_t len = possibleLengths[i];

    if (len > maxDataLen) continue;

 

    uint16_t sum = fullPID;

    for (uint8_t j = 0; j < len; j++) {

      sum += frameBuffer[dataStart + j];

      if (sum >= 256) sum -= 255;

    }

    calculated = (~sum) & 0xFF;

 

    if (calculated == receivedChecksum) {

      detectedLen = len;

      break;

    }

  }

 

  // If no match, use maximum length received for display + show error

  if (detectedLen == 0) {

    detectedLen = maxDataLen;

    uint16_t sum = fullPID;

    for (uint8_t j = 0; j < detectedLen; j++) {

      sum += frameBuffer[dataStart + j];

      if (sum >= 256) sum -= 255;

    }

    calculated = (~sum) & 0xFF;

  }

 

  // ====================== PRINT IN YOUR REQUESTED FORMAT ======================

 

  // 1. Show full PID

  Serial.print("PID: 0x");

  if (fullPID < 0x10) Serial.print("0");

  Serial.print(fullPID, HEX);

 

  // 2. Show Data

  Serial.print("  Data: ");

  for (uint8_t i = 0; i < detectedLen; i++) {

    if (frameBuffer[dataStart + i] < 0x10) Serial.print("0");

    Serial.print(frameBuffer[dataStart + i], HEX);

    Serial.print(" ");

  }

 

  // 3. Show received checksum

  Serial.print(" CHK: 0x");

  if (receivedChecksum < 0x10) Serial.print("0");

  Serial.print(receivedChecksum, HEX);

 

  // 4. Show Raw ID in brackets at the end

  Serial.print("   (Raw ID: 0x");

  if (rawID < 0x10) Serial.print("0");

  Serial.print(rawID, HEX);

  Serial.print(")");

 

  // 5. Show checksum type and status

  Serial.print(" [Enhanced] ");

 

  if (calculated == receivedChecksum) {

    Serial.println("[OK]");

  } else {

    Serial.print("[CHECKSUM ERROR: Calc 0x");

    if (calculated < 0x10) Serial.print("0");

    Serial.print(calculated, HEX);

    Serial.println("]");

  }

}

 
  
