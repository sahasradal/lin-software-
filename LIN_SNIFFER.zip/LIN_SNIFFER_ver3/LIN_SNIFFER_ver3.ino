//under development
int recPin = 0;  //the pin receiving the serial input data
long baudRate;   // global in case useful elsewhere in a sketch
int incomingByte = 0; // for incoming serial data
const unsigned int MAX_MESSAGE_LENGTH1 = 12;
const unsigned int MAX_MESSAGE_LENGTH2 = 5;
const unsigned int MAX_MESSAGE_LENGTH3 = 7;
const unsigned int MAX_MESSAGE_LENGTH4 = 11;

void setup()
 {
  pinMode(recPin, INPUT);      // make sure serial in is a input pin
  digitalWrite (recPin, HIGH); // pull up enabled just for noise protection
  
  baudRate = detRate(recPin);  // Function finds a standard baudrate of either
                               // 1200,2400,4800,9600,14400,19200,28800,38400,57600,115200 
                               // by having sending circuit send "U" characters.
                               // Returns 0 if none or under 1200 baud  
  Serial.begin(9600);
  Serial.println();
  Serial.print("Detecting LIN traffic ");
  Serial.println();
  Serial.print("Detected baudrate at ");
  Serial.println(baudRate);
  Serial.end();
  Serial.begin(baudRate);
 }

void loop()
 {
  while (Serial.available() > 0)
  {
   static int message[MAX_MESSAGE_LENGTH1];
   static unsigned int message_pos = 0;
   char EOL[3];
   int inByte = Serial.read();

   if  (message_pos < MAX_MESSAGE_LENGTH1 ) 
   {
     message[message_pos] = inByte;               // current byte store in new position in array
     message_pos++;                               // increase messsge position
     if (message_pos == 3)                        // if message position is 3 or if we are looking at 3rd byte
     {byte extractedBits = inByte & 0x3f;         // AND inByte with 0x3f to extract lower 5 bits
      if (extractedBits <= 0x1f)                  // if extracted bits equal to or less than 0x1f
      {static int message[MAX_MESSAGE_LENGTH2];}  // change max message length to 5
      if ((extractedBits >= 0x20)  && (extractedBits <= 0x2f))  // if extracted bits equal to 0x20 and less than or equal to 0x2f  
      {static int message[MAX_MESSAGE_LENGTH3];}                // change max message length to 7
      if ((extractedBits >= 0x30)  && (extractedBits <= 0x3f))  // if extracted bits equal to 0x30 and less than or equal to 0x3f 
      {static int message[MAX_MESSAGE_LENGTH4];}                // change max message length to 11
     }
   }
          //Full message received...
   else
   {
     //null,new line and carraiage return i new array as the message array is integer,the below are characters
     
     EOL[0] = '\n';                           // char array EOL will hold new line in 0 index 
     EOL[1] = '\r';                           // char array EOL will hold carriage return in 1 index
     EOL[2] = '\0';                           // char array EOL will hold null terminator in 2 index
     Serial.end();
     Serial.begin(9600);
     //Print the message (or do other things)
     //Serial.println(messageC);
     for (auto x : message)
    {
    Serial.print(x,HEX);                      // serial prints element x in array message[]
    Serial.print(',');
    }
    for (auto x : EOL)
    {
    Serial.print(x);                          // prints end of line characters from array EOL[]
    }
     //Reset for the next message
     message_pos = 0;
     Serial.end();
     Serial.begin(baudRate);
   }
 }
   
 }

long detRate(int recpin)                    // function to return valid received baud rate
                                            // Note that the serial monitor has no 600 baud option and 300 baud
                                            // doesn't seem to work with version 22 hardware serial library
  {
   while(digitalRead(recpin) == 1){}        // wait for low bit to start
   long baud;
   long rate = pulseIn(recpin,LOW);         // measure zero bit width from character 'U'
   if(rate>=1){  
      baud = 1000000/rate;}
      else 
      baud = 0;  
   return baud; 
  }
