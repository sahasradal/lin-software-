void setup() {
 pinMode(1, OUTPUT);
 digitalWrite(1, HIGH);
// Serial.begin (9600);
 delay(500);
}

void loop() {
  
digitalWrite(1, LOW);     // 3.3us
delayMicroseconds(1349);  // sync break 13 bit
digitalWrite(1, HIGH);    // 3.2us
delayMicroseconds(90);    // delimiter 1 bit ,12us added when serialbegin is called
Serial.begin (9600);      // 12us
Serial.write('U');        // sync byte
Serial.write(0x84);       // id
delay(1);                 // 1ms delay for byte space
Serial.write(0x00);       // data 1
Serial.write(0x01);       // data 2
Serial.write(0x02);       // data 3
Serial.write(0x03);       // data 4
Serial.write(0x04);       // data 5
Serial.write(0x05);       // data 6
Serial.write(0x06);       // data 7
Serial.write(0x07);       // data 8
Serial.write(0x08);       // check sum
Serial.end();
delay(500);

}
