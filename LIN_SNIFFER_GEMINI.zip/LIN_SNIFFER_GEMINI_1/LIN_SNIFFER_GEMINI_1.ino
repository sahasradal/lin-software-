#include <SoftwareSerial.h>

// PIN CONFIGURATION
const int linRX = 2; // Connect your LIN signal (via divider) here
const int linTX = 3; // Not strictly used for reading, but needed for SoftwareSerial
SoftwareSerial linBus(linRX, linTX);

long baudRate = 0;
const int MAX_BUFFER = 12;
uint8_t buffer[MAX_BUFFER];
int bufferIndex = 0;

void setup() {
  // 1. Start Debug Serial (USB)
  Serial.begin(9600);
  while (!Serial); 
  Serial.println("--- LIN Bus Auto-Detect Starting ---");

  // 2. Hardware Pin Setup
  pinMode(linRX, INPUT); 
  // Note: No internal pull-up. Let the LIN bus 1k/30k resistors do the work.

  // 3. Auto-Detect Baud Rate
  // We look for the 0x55 Sync byte which follows the 'Break'
  baudRate = detectLinBaud(linRX);
  
  if (baudRate > 0) {
    Serial.print("Detected Baud Rate: ");
    Serial.println(baudRate);
    linBus.begin(baudRate);
  } else {
    Serial.println("Error: No LIN traffic detected. Check connections.");
    while(1); // Halt if no signal
  }
}

void loop() {
  if (linBus.available()) {
    uint8_t inByte = linBus.read();
    
    // Store in buffer
    if (bufferIndex < MAX_BUFFER) {
      buffer[bufferIndex++] = inByte;
    }

    // Logic: If we haven't received a byte for a while, assume end of frame
    // LIN frames are typically separated by an Inter-Byte Space or a new Break
    static unsigned long lastByteTime = 0;
    if (millis() - lastByteTime > 10 && bufferIndex > 0) {
      printFrame();
      bufferIndex = 0;
    }
    lastByteTime = millis();
  }
}

// Function to print the captured frame in HEX
void printFrame() {
  Serial.print("Frame: ");
  for (int i = 0; i < bufferIndex; i++) {
    if (buffer[i] < 0x10) Serial.print("0");
    Serial.print(buffer[i], HEX);
    Serial.print(" ");
  }
  Serial.println();
}

// Improved Baud Rate Detection using the 0x55 Sync Field
long detectLinBaud(int pin) {
  Serial.println("Waiting for Sync Byte (0x55)...");
  
  // A LIN Sync byte (0x55) has 5 falling edges. 
  // We measure the width of one 'Low' pulse within that byte.
  // 1. Wait for a very long LOW (The LIN Break Field)
  while(pulseIn(pin, LOW, 100000) < 500); 

  // 2. The very next LOW pulse is the first bit of the 0x55 Sync Byte
  long bitWidth = pulseIn(pin, LOW, 10000); 
  
  if (bitWidth <= 0) return 0;

  long detected = 1000000 / bitWidth;

  // Standardize to nearest common LIN speed
  if (detected > 18000 && detected < 21000) return 19200;
  if (detected > 9000 && detected < 11500) return 10417; // GM Standard
  if (detected > 8000 && detected < 10000) return 9600;
  
  return detected; // Return raw if not standard
}


/**
 * Calculates the LIN 2.x Enhanced Checksum.
 * @param pid The Protected Identifier (e.g., 0xC1 for ID 0x01)
 * @param data Pointer to the array of data bytes
 * @param length Number of data bytes (usually 8)
 * @return The calculated 8-bit checksum
 */
uint8_t calculateEnhancedChecksum(uint8_t pid, uint8_t* data, uint8_t length) {
  uint16_t sum = pid; // Enhanced includes the PID in the sum

  for (uint8_t i = 0; i < length; i++) {
    sum += data[i];
    if (sum > 255) {
      sum -= 255; // Wrap the carry bit back into the 8-bit sum
    }
  }

  // The final checksum is the bitwise inverse of the sum
  return (uint8_t)(~sum);
}
