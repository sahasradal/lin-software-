#include <SoftwareSerial.h>

const int linRX = 2; 
SoftwareSerial linBus(2, 3);
long detectedBaud = 0;
uint8_t frameBuffer[20];
int bufIdx = 0;
unsigned long lastByteTime = 0;

void setup() {
  Serial.begin(115200);
  Serial.println("=== LIN Bus Monitor - Complete Bus Trace ===");
  Serial.println("Showing ALL frames (Master requests + Slave responses)");
  Serial.println();
}

void loop() {       
  if (detectedBaud == 0) {
    detectedBaud = autoDetectBaud(linRX);
    if (detectedBaud > 0) {
      Serial.print("Detected Baud: "); 
      Serial.println(detectedBaud);
      Serial.println();
      linBus.begin(detectedBaud);
    }
    return;
  }

  while (linBus.available()) {
    uint8_t b = linBus.read();
    lastByteTime = millis();
    
    if (b == 0x55) {
      if (bufIdx > 0) {
        processLastFrame();
      }
      bufIdx = 0;
      frameBuffer[bufIdx++] = b;
    } 
    else if (bufIdx > 0) {
      if (bufIdx < 20) {
        frameBuffer[bufIdx++] = b;
      }
      
      if (bufIdx >= 3 && linBus.available() == 0) {
        delay(1);
        if (linBus.available() == 0) {
          processLastFrame();
          bufIdx = 0;
        }
      }
    }
    
    if (bufIdx > 0 && (millis() - lastByteTime) > 10) {
      if (bufIdx >= 3) {
        processLastFrame();
      }
      bufIdx = 0;
    }
  }
}

long autoDetectBaud(int pin) {
  unsigned long timeout = millis() + 5000;
  long bitWidth = 0;
  
  while (millis() < timeout) {
    long breakWidth = pulseIn(pin, LOW, 500000);
    if (breakWidth > 500) {
      bitWidth = pulseIn(pin, LOW, 10000);
      if (bitWidth > 0) {
        long raw = 1000000 / bitWidth;
        if (raw > 18000 && raw < 21000) return 19200;
        if (raw > 9500 && raw < 11500)  return 10417;
        return raw;
      }
    }
    delay(1);
  }
  return 0;
}

void processLastFrame() {
  if (bufIdx < 3) return;
  
  uint8_t syncByte = frameBuffer[0];
  uint8_t fullPID = frameBuffer[1];
  uint8_t rawID = fullPID & 0x3F;
  uint8_t receivedChecksum = frameBuffer[bufIdx - 1];
  uint8_t dataBytesCount = bufIdx - 3;
  
  // Try to find correct data length
  uint8_t detectedLen = 0;
  uint8_t calculated = 0;
  bool checksumValid = false;
  
  for (uint8_t len = 0; len <= dataBytesCount && len <= 8; len++) {
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < len; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    uint8_t calc = (~sum) & 0xFF;
    
    if (calc == receivedChecksum) {
      detectedLen = len;
      calculated = calc;
      checksumValid = true;
      break;
    }
  }
  
  if (!checksumValid) {
    detectedLen = dataBytesCount;
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < detectedLen; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    calculated = (~sum) & 0xFF;
  }
  
  // Determine if this is a master request or slave response
  bool isMasterRequest = (dataBytesCount == 0) || 
                         (dataBytesCount == 1 && frameBuffer[2] == 0xFF) ||
                         (rawID >= 0x00 && rawID <= 0x0F); // Common master request IDs
  
  // Actually, on LIN bus, the master always sends the header (PID)
  // Slave only responds if it's a response frame (data bytes present)
  bool isSlaveResponse = (dataBytesCount > 0);
  
  // Format the output nicely
  Serial.print("["); 
  Serial.print(millis() - lastByteTime + millis());
  Serial.print("ms] ");
  
  // Show direction indicator
  if (isSlaveResponse && checksumValid && dataBytesCount > 0) {
    Serial.print("← Slave  ");
  } else if (dataBytesCount == 0) {
    Serial.print("→ Master ");
  } else {
    Serial.print("? Unknown ");
  }
  
  // Show frame details
  Serial.print("ID:0x");
  if (rawID < 0x10) Serial.print("0");
  Serial.print(rawID, HEX);
  
  Serial.print(" PID:0x");
  if (fullPID < 0x10) Serial.print("0");
  Serial.print(fullPID, HEX);
  
  // Show data
  if (dataBytesCount > 0) {
    Serial.print(" Data[");
    Serial.print(detectedLen);
    Serial.print("]: ");
    
    for (int i = 2; i < 2 + detectedLen && i < bufIdx - 1; i++) {
      if (frameBuffer[i] < 0x10) Serial.print("0");
      Serial.print(frameBuffer[i], HEX);
      Serial.print(" ");
    }
  } else {
    Serial.print(" (Header only)");
  }
  
  // Show checksum
  Serial.print(" CS:0x");
  if (receivedChecksum < 0x10) Serial.print("0");
  Serial.print(receivedChecksum, HEX);
  
  if (checksumValid) {
    Serial.print(" ✓");
  } else {
    Serial.print(" ✗ (Calc:0x");
    if (calculated < 0x10) Serial.print("0");
    Serial.print(calculated, HEX);
    Serial.print(")");
  }
  
  // Add decoding for known values (if it's a slave response with valid data)
  if (isSlaveResponse && checksumValid && detectedLen > 0) {
    if (rawID == 0x16 && detectedLen >= 4) {
      int voltage = (frameBuffer[2] << 8) | frameBuffer[3];
      Serial.print(" → Battery:");
      Serial.print(voltage / 100.0, 2);
      Serial.print("V");
      if (detectedLen >= 5) {
        Serial.print(" Temp:");
        Serial.print(frameBuffer[4] - 40);
        Serial.print("°C");
      }
    }
    else if (rawID == 0x17 && detectedLen >= 5) {
      int current = (frameBuffer[3] << 8) | frameBuffer[2];
      if (current > 32767) current -= 65536;
      Serial.print(" → Current:");
      Serial.print(current / 10.0, 1);
      Serial.print("A");
    }
    else if (rawID == 0x10 && detectedLen >= 5) {
      int voltage = (frameBuffer[2] << 8) | frameBuffer[3];
      Serial.print(" → Battery:");
      Serial.print(voltage / 100.0, 2);
      Serial.print("V");
    }
  }
  
  Serial.println();
}
