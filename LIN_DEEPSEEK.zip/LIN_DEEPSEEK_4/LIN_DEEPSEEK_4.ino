#include <SoftwareSerial.h>
// works for 2.xx version, reads all data 
const int linRX = 2; 
SoftwareSerial linBus(2, 3);
long detectedBaud = 0;
uint8_t frameBuffer[20];
int bufIdx = 0;
unsigned long lastByteTime = 0;

void setup() {
  Serial.begin(115200);
  Serial.println("=== LIN Bus Monitor - Complete Bus Trace ===");
  Serial.println("Showing ALL frames (Master requests + Slave responses)");
  Serial.println();
}

void loop() {       
  if (detectedBaud == 0) {
    detectedBaud = autoDetectBaud(linRX);
    if (detectedBaud > 0) {
      Serial.print("Detected Baud: "); 
      Serial.println(detectedBaud);
      Serial.println();
      linBus.begin(detectedBaud);
    }
    return;
  }

  while (linBus.available()) {
    uint8_t b = linBus.read();
    lastByteTime = millis();
    
    if (b == 0x55) {
      if (bufIdx > 0) {
        processLastFrame();
      }
      bufIdx = 0;
      frameBuffer[bufIdx++] = b;
    } 
    else if (bufIdx > 0) {
      if (bufIdx < 20) {
        frameBuffer[bufIdx++] = b;
      }
      
      // Process when we have a reasonable number of bytes
      if (bufIdx >= 3 && linBus.available() == 0) {
        delay(2); // Wait longer for all bytes to arrive
        if (linBus.available() == 0) {
          processLastFrame();
          bufIdx = 0;
        }
      }
    }
    
    if (bufIdx > 0 && (millis() - lastByteTime) > 15) {
      if (bufIdx >= 3) {
        processLastFrame();
      }
      bufIdx = 0;
    }
  }
}

long autoDetectBaud(int pin) {
  unsigned long timeout = millis() + 5000;
  long bitWidth = 0;
  
  while (millis() < timeout) {
    long breakWidth = pulseIn(pin, LOW, 500000);
    if (breakWidth > 500) {
      bitWidth = pulseIn(pin, LOW, 10000);
      if (bitWidth > 0) {
        long raw = 1000000 / bitWidth;
        if (raw > 18000 && raw < 21000) return 19200;
        if (raw > 9500 && raw < 11500)  return 10417;
        return raw;
      }
    }
    delay(1);
  }
  return 0;
}

void processLastFrame() {
  if (bufIdx < 3) return;
  
  uint8_t syncByte = frameBuffer[0];
  uint8_t fullPID = frameBuffer[1];
  uint8_t rawID = fullPID & 0x3F;
  uint8_t receivedChecksum = frameBuffer[bufIdx - 1];
  uint8_t dataBytesCount = bufIdx - 3;
  
  // Try to find correct data length - but we need to be more careful
  uint8_t detectedLen = 0;
  uint8_t calculated = 0;
  bool checksumValid = false;
  uint8_t validLengths[10];
  int validCount = 0;
  
  // Try all possible data lengths
  for (uint8_t len = 0; len <= dataBytesCount && len <= 8; len++) {
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < len; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    uint8_t calc = (~sum) & 0xFF;
    
    if (calc == receivedChecksum) {
      validLengths[validCount++] = len;
      if (!checksumValid) {
        detectedLen = len;
        calculated = calc;
        checksumValid = true;
      }
    }
  }
  
  // If multiple valid lengths found, use the longest one that makes sense
  // (because zeros at the end could cause false positives with shorter lengths)
  if (validCount > 1) {
    // Sort valid lengths and take the largest
    for (int i = 0; i < validCount; i++) {
      if (validLengths[i] > detectedLen) {
        detectedLen = validLengths[i];
      }
    }
    
    // Recalculate checksum for the selected length
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < detectedLen; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    calculated = (~sum) & 0xFF;
  }
  
  if (!checksumValid) {
    detectedLen = dataBytesCount;
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < detectedLen; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    calculated = (~sum) & 0xFF;
  }
  
  // Determine if this is a master request or slave response
  bool isSlaveResponse = (dataBytesCount > 0);
  
  // Format the output nicely
  Serial.print("[");
  Serial.print(millis());
  Serial.print("ms] ");
  
  // Show direction indicator
  if (isSlaveResponse && dataBytesCount > 0) {
    Serial.print("← Slave  ");
  } else if (dataBytesCount == 0) {
    Serial.print("→ Master ");
  } else {
    Serial.print("? Unknown ");
  }
  
  // Show frame details
  Serial.print("ID:0x");
  if (rawID < 0x10) Serial.print("0");
  Serial.print(rawID, HEX);
  
  Serial.print(" PID:0x");
  if (fullPID < 0x10) Serial.print("0");
  Serial.print(fullPID, HEX);
  
  // Show ALL data bytes captured (raw frame)
  Serial.print(" Raw[");
  Serial.print(dataBytesCount);
  Serial.print("]: ");
  
  for (int i = 2; i < bufIdx - 1; i++) {
    if (frameBuffer[i] < 0x10) Serial.print("0");
    Serial.print(frameBuffer[i], HEX);
    Serial.print(" ");
  }
  
  // Show interpreted data with detected length
  if (detectedLen > 0) {
    Serial.print(" → Data[");
    Serial.print(detectedLen);
    Serial.print("]: ");
    
    for (int i = 2; i < 2 + detectedLen; i++) {
      if (frameBuffer[i] < 0x10) Serial.print("0");
      Serial.print(frameBuffer[i], HEX);
      Serial.print(" ");
    }
  }
  
  // Show checksum info
  Serial.print(" CS:0x");
  if (receivedChecksum < 0x10) Serial.print("0");
  Serial.print(receivedChecksum, HEX);
  
  if (checksumValid) {
    if (validCount > 1) {
      Serial.print(" ✓ [");
      Serial.print(validCount);
      Serial.print(" valid lengths: ");
      for (int i = 0; i < validCount; i++) {
        Serial.print(validLengths[i]);
        if (i < validCount - 1) Serial.print(",");
      }
      Serial.print("]");
    } else {
      Serial.print(" ✓");
    }
  } else {
    Serial.print(" ✗ (Calc:0x");
    if (calculated < 0x10) Serial.print("0");
    Serial.print(calculated, HEX);
    Serial.print(")");
  }
  
  // Add decoding for known values
  if (isSlaveResponse && checksumValid && detectedLen >= 4) {
    if (rawID == 0x16 && detectedLen >= 4) {
      int voltage = (frameBuffer[2] << 8) | frameBuffer[3];
      Serial.print(" → Battery:");
      Serial.print(voltage / 100.0, 2);
      Serial.print("V");
      if (detectedLen >= 5) {
        Serial.print(" Temp:");
        Serial.print(frameBuffer[4] - 40);
        Serial.print("°C");
      }
    }
    else if (rawID == 0x17 && detectedLen >= 5) {
      int current = (frameBuffer[3] << 8) | frameBuffer[2];
      if (current > 32767) current -= 65536;
      Serial.print(" → Current:");
      Serial.print(current / 10.0, 1);
      Serial.print("A");
    }
    else if (rawID == 0x1D && detectedLen >= 5) {
      int value = (frameBuffer[2] << 24) | (frameBuffer[3] << 16) | 
                  (frameBuffer[4] << 8) | frameBuffer[5];
      Serial.print(" → Raw:0x");
      Serial.print(value, HEX);
    }
  }
  
  Serial.println();
}
