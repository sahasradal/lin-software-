#include <SoftwareSerial.h>

const int linRX = 2; 
SoftwareSerial linBus(2, 3);
long detectedBaud = 0;
uint8_t frameBuffer[20];
int bufIdx = 0;
unsigned long lastByteTime = 0;

void setup() {
  Serial.begin(115200);
  Serial.println("--- LIN 2.x Complete Frame Sniffer (Full Data Display) ---");
}

void loop() {       
  if (detectedBaud == 0) {
    detectedBaud = autoDetectBaud(linRX);
    if (detectedBaud > 0) {
      Serial.print("Detected Baud: "); 
      Serial.println(detectedBaud);
      linBus.begin(detectedBaud);
    }
    return;
  }

  while (linBus.available()) {
    uint8_t b = linBus.read();
    lastByteTime = millis();
    
    if (b == 0x55) {
      if (bufIdx > 0) {
        processLastFrame();
      }
      bufIdx = 0;
      frameBuffer[bufIdx++] = b;
    } 
    else if (bufIdx > 0) {
      if (bufIdx < 20) {
        frameBuffer[bufIdx++] = b;
      }
      
      if (bufIdx >= 3 && linBus.available() == 0) {
        delay(1);
        if (linBus.available() == 0) {
          processLastFrame();
          bufIdx = 0;
        }
      }
    }
    
    if (bufIdx > 0 && (millis() - lastByteTime) > 10) {
      if (bufIdx >= 3) {
        processLastFrame();
      }
      bufIdx = 0;
    }
  }
}

long autoDetectBaud(int pin) {
  unsigned long timeout = millis() + 5000;
  long bitWidth = 0;
  
  while (millis() < timeout) {
    long breakWidth = pulseIn(pin, LOW, 500000);
    if (breakWidth > 500) {
      bitWidth = pulseIn(pin, LOW, 10000);
      if (bitWidth > 0) {
        long raw = 1000000 / bitWidth;
        if (raw > 18000 && raw < 21000) return 19200;
        if (raw > 9500 && raw < 11500)  return 10417;
        return raw;
      }
    }
    delay(1);
  }
  return 0;
}

void processLastFrame() {
  if (bufIdx < 3) return;
  
  uint8_t syncByte = frameBuffer[0];
  uint8_t fullPID = frameBuffer[1];
  uint8_t rawID = fullPID & 0x3F;
  uint8_t receivedChecksum = frameBuffer[bufIdx - 1];
  uint8_t totalBytes = bufIdx;
  
  // Try to find correct data length by checking all possibilities
  uint8_t detectedLen = 0;
  uint8_t calculated = 0;
  bool checksumValid = false;
  uint8_t validLengths[8];
  int validCount = 0;
  
  // Try all possible data lengths
  for (uint8_t len = 0; len <= (bufIdx - 3) && len <= 8; len++) {
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < len; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    uint8_t calc = (~sum) & 0xFF;
    
    if (calc == receivedChecksum) {
      validLengths[validCount++] = len;
      if (!checksumValid) {
        detectedLen = len;
        calculated = calc;
        checksumValid = true;
      }
    }
  }
  
  // If multiple valid lengths found, use the one that matches typical patterns
  if (validCount > 1) {
    // For ID 0x16, prefer length 4 or 5 based on your data patterns
    for (int i = 0; i < validCount; i++) {
      if (validLengths[i] == 4 || validLengths[i] == 5) {
        detectedLen = validLengths[i];
        break;
      }
    }
  }
  
  if (!checksumValid) {
    detectedLen = bufIdx - 3;
    uint16_t sum = fullPID;
    for (uint8_t j = 0; j < detectedLen; j++) {
      sum += frameBuffer[2 + j];
      if (sum >= 256) sum -= 255;
    }
    calculated = (~sum) & 0xFF;
  }
  
  // Display frame information
  Serial.print("ID: 0x");
  if (rawID < 0x10) Serial.print("0");
  Serial.print(rawID, HEX);
  
  Serial.print(" (PID:0x");
  if (fullPID < 0x10) Serial.print("0");
  Serial.print(fullPID, HEX);
  Serial.print(") ");
  
  // Show ALL captured bytes with their positions
  Serial.print("Bytes[");
  Serial.print(totalBytes);
  Serial.print("]: ");
  
  for (int i = 0; i < totalBytes; i++) {
    if (frameBuffer[i] < 0x10) Serial.print("0");
    Serial.print(frameBuffer[i], HEX);
    if (i == 0) Serial.print("[Sync] ");
    else if (i == 1) Serial.print("[PID] ");
    else if (i == totalBytes - 1) Serial.print("[CHK] ");
    else Serial.print(" ");
  }
  
  // Show interpreted data
  Serial.print(" -> Data(");
  Serial.print(detectedLen);
  Serial.print("): ");
  
  for (int i = 2; i < 2 + detectedLen && i < totalBytes - 1; i++) {
    if (frameBuffer[i] < 0x10) Serial.print("0");
    Serial.print(frameBuffer[i], HEX);
    Serial.print(" ");
  }
  
  Serial.print(" CHK:0x");
  if (receivedChecksum < 0x10) Serial.print("0");
  Serial.print(receivedChecksum, HEX);
  
  if (checksumValid) {
    if (validCount > 1) {
      Serial.print(" [OK - "); 
      Serial.print(validCount);
      Serial.print(" valid lengths found]");
    } else {
      Serial.print(" [OK]");
    }
  } else {
    Serial.print(" [ERROR] Calc:0x");
    if (calculated < 0x10) Serial.print("0");
    Serial.print(calculated, HEX);
  }
  
  Serial.println();
}
